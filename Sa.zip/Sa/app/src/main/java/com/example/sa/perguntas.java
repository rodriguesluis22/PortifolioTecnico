package com.example.sa;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class perguntas extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_peruntas_cursos);
    }
}