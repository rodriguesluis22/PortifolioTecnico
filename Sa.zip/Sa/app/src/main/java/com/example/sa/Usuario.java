package com.example.sa;

public class Usuario {
    String login, senha;

    public Usuario(String login, String senha) {
        this.login = login;
        this.senha = senha;
    }

}
