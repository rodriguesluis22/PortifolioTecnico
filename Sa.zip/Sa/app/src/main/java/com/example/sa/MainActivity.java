package com.example.sa;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText user, senha;
    AlertDialog.Builder alerta;
    ArrayList<Usuario> Lista = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        alerta = new AlertDialog.Builder(this);
        user = findViewById(R.id.logintxt);
        senha = findViewById(R.id.senhatxt);

        Usuario v1 = new Usuario("Felipe", "123");
        Lista.add(v1);

    }

    public boolean verificaUsuario(String login, String senha){
        for(Usuario pessoa : Lista){
            if(login.equals(pessoa.login) && senha.equals(pessoa.senha)){
                return true;
            }
        }
        return false;
    }

    public void cadastro(View e){
        String msg = "Login ou senha já existentes";
        String texto = user.getText().toString();
        String pass = senha.getText().toString();
        if (verificaUsuario(texto, pass)){
            alerta.setMessage(msg);
            alerta.show();
        }else{
            criaUsuario();
        }

    }

    public void criaUsuario(){
        String l = user.getText().toString();
        String s = senha.getText().toString();
        Usuario u = new Usuario(l, s);
        Lista.add(u);
        Toast.makeText(this, "Usuário Criado!", Toast.LENGTH_SHORT).show();
        user.setText(null);
        senha.setText(null);
    }

    public void entrar(View v){
        String msg = "usuário ou senha inválido, tente novamente";
        String texto = user.getText().toString();
        String pass = senha.getText().toString();
        if(verificaUsuario(texto, pass)){
            Toast.makeText(this, "Bem vindo, "+texto, Toast.LENGTH_SHORT).show();
            mudaTela();
        }else{
            alerta.setMessage(msg);
            alerta.show();
        }
    }


    public void mudaTela(){
        Intent i = new Intent(this, Comeco.class);
        startActivity(i);
    }
}